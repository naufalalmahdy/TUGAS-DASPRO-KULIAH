﻿//NAUFAL AL-MAHDY AMARA PUTRA
//2207125069
//Teknik Informatika - B
//Game Adventure

using System;

namespace AdventureGame
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to My Adventure");
            Console.WriteLine("What is Your Name?");
            Novice player = new Novice();
            player.Name = Console.ReadLine();
            Console.WriteLine("Hi "+player.Name+", ready to begin the game? [Yes/No]");
            string bReady = Console.ReadLine();
            if(bReady=="Yes"){
                Console.WriteLine(player.Name+ " is entering the world...");

                Enemy Enemy = new Enemy ("Monster");

                Console.WriteLine(player.Name+" is encountering "+Enemy.Name);
                Console.WriteLine(Enemy.Name+" attacking you...");
                Console.WriteLine("1. Single Attack");
                Console.WriteLine("2. Swing Attack");
                Console.WriteLine("3. Defend");
                Console.WriteLine("4. Run Away");
                
                while (!player.IsDead && !Enemy.IsDead)
                {
                    string playerAction = Console.ReadLine();
                    switch(playerAction){
                        case "1" :
                        Console.WriteLine(player.Name+" is doing single Attack!");
                        player.Experience += 0.5f;
                        Enemy.GetHit(player.AttackPower);
                        Enemy.Attack(Enemy.AttackPower);
                        player.GetHit(Enemy.AttackPower);
                        Console.WriteLine($"Your Health {player.Healt} | Enemy Health : {Enemy.Healt}");
                        Console.WriteLine($"Your energy skill is : {player.SkillSlot}");
                        break;

                        case "2" :
                        player.Swing();
                        player.Experience += 0.5f;
                        Enemy.GetHit(player.AttackPower);
                        Console.WriteLine($"Your Health {player.Healt} | Enemy Health : {Enemy.Healt}");
                        Console.WriteLine($"Your energy skill is : {player.SkillSlot}");
                        break;

                        case "3" :
                        player.Rest();
                        Console.WriteLine("Energy is being restored..");
                        Enemy.Attack(Enemy.AttackPower);
                        player.GetHit(Enemy.AttackPower);
                        Console.WriteLine($"Your Health {player.Healt} | Enemy Health : {Enemy.Healt}");
                        Console.WriteLine($"Your energy skill is : {player.SkillSlot}");
                        break;

                        case "4" :
                        Console.WriteLine(player.Name+" is running away...");
                        break;
                    }
                }
                Console.WriteLine($"You get {player.Experience} experience point from kill {Enemy.Name}");
                Console.WriteLine("Press Enter");
                Console.ReadLine();
                Console.Clear();

            }
              Console.WriteLine("GoodBye...");            
          }
        }
        class Novice
        {
            public int Healt { get; set; }
            public string Name { get; set; }
            public int AttackPower { get; set; }
            public int SkillSlot { get; set; }
            public float Experience { get; set; }
            public bool IsDead { get; set; }
            Random rnd = new Random();

            public Novice(){
                Healt = 500;
                SkillSlot = 0;
                AttackPower = 10;
                IsDead = false;
                Experience = 0f;
                

            }
            
            public void Swing()
            {
             if(SkillSlot > 0){
              Console.WriteLine("SWINGG!!!");
              AttackPower = AttackPower + rnd.Next(5,26);
              Experience += 0.5f;
              SkillSlot--;
             }else{
                Console.WriteLine("You do not have energy!");
             }
             
            }
            public void GetHit(int HitValue)
            {
              Console.WriteLine(Name+" Get hit by "+HitValue);
              Healt = Healt - HitValue;

              if(Healt <= 0){
                Healt = 0;
                Die();
              }
            }
            public void Rest()
            {
              SkillSlot = 5;
              AttackPower = 10;
            }
            public void Die()
            {
              Console.Clear();
              Console.WriteLine("You are dead,Game over!");
              IsDead = true;   
            }
        }
        class Enemy
        {
            public string Name { get; set; }
            public int Healt { get; set; }
            public int AttackPower { get; set; }
            public bool IsDead { get; set; }
            Random rnd = new Random();

            public Enemy(string name){
                Healt = 300;
                Name = name;
            }

            public void Attack(int damage)
            {
              AttackPower = rnd.Next(5,26);
            }
            public void GetHit(int HitValue)
            {
              Console.WriteLine(Name+" Get hit by "+HitValue);
              Healt = Healt - HitValue;

              if(Healt <= 0){
                Healt = 0;
                Die();
              }
            }
            public void Die()
            {
              Console.WriteLine(Name+" Is dead");
              IsDead = true;             
            }      
   } 
 }
