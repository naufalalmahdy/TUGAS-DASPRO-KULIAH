﻿using System;

namespace UTS
{
    internal class Program
    {
        static void Main(string[] args)
        {
            float
            rate,
            usd;

            Console.WriteLine("Rate USD ke Rp :");
            rate = float.Parse(Console.ReadLine());
            Console.WriteLine("Jumlah USD : ");
            usd = float.Parse(Console.ReadLine());
            Console.WriteLine("Hasil Konversi : " + rate*usd);

        }
    }
}