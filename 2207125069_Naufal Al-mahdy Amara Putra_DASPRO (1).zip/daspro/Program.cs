﻿// Hello World! program
using System;

namespace daspro
{
    class program
    {
        //Main Method
      static void Main(string[] args)
        {
               //Deklarasi Variabel
                const int a = 5;
                const int b = 4;
                const int c = 7;

                int tambah = a+b+c;
                int kali = a*b*c;
                int bagi = a/b/c;
             
      //Menuliskan Narasi
            Console.WriteLine("Anda adalah seorang agen rahasia mendapatkan data dari server");
            Console.WriteLine("Akses ke server membutuhkan password yang tidak diketahui...");
            Console.WriteLine("- Password terdiri dari 4 angka");
            Console.WriteLine("- Jika ditambahkan hasilnya "+tambah);
            Console.WriteLine("Jika dikalikan maka hasilnya "+kali);
            Console.WriteLine("Jika dibagikan maka hasilnya "+bagi);
            Console.WriteLine("");
            Console.Write("Enter Code");
        }
    }
}